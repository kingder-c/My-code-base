describe("less.js legacy tests", function() {
    testLessEqualsInDocument();
});
