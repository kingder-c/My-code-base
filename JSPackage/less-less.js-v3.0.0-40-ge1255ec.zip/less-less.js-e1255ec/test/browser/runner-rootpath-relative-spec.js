describe("less.js browser test - rootpath and relative url's", function() {
    testLessEqualsInDocument();
});
