registerPlugin({
    use: function() {
        throw new Error("An error was here.")
    }
});